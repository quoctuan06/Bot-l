# c3c-fbstate
A Chrome extension. Used to import/export fbstate.json file to be used with C3C or any other bots based on fca-unofficial/facebook-chat-api.

See how to install this thing: https://www.youtube.com/embed/KN6UzbisSFo

-----

(Vietnamese-only since the following PSA is for people (mostly in VN) running a forked, malicious package of facebook-chat-api, fca-unofficial, ts-messenger-api):

## PSA: CẢNH BÁO VỀ VIỆC SỬ DỤNG CÁC PACKAGE MOD TRÀN LAN TRÊN CÁC GROUP

GitHub/npm đã đánh dấu một số package thường được share trên các group chatbot có chứa malware (malicious code) với lý do có chứa mã nguồn đã được mã hoá và vi phạm [npm Open Source Terms](https://docs.npmjs.com/policies/open-source-terms) vì thế **KHUYẾN KHÍCH** không sử dụng các package này nếu không muốn tự tạo nguy cơ bị hack (hoặc bạn tự chịu trách nhiệm về hành vi của mình).

**HÃY SỬ DỤNG PACKAGE RÕ NGUỒN GỐC VÀ UY TÍN!**
